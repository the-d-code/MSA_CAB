# ANACONDA_SPYDER
This Repo contain code perform in lab OF PYTHON BASIC

Lab work 

anaconda lab work done ict 3