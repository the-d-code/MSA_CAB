 // ----------Array-----------------  
        
                        mylist=[[1,2,3],["Hemali","Devanshi","D"]]
                        print(mylist[1][1])
                
                                runfile('C:/Users/admin/untitled0.py', wdir='C:/Users/admin')
                                Devanshi
      
                // ------Insert the item-------------------
                                
                        mylist=[[1,2,3],["Hemali","Devanshi","D"]]
                        mylist.append("NEW")
                        print(mylist)
        
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                [[1, 2, 3], ['Hemali', 'Devanshi', 'D'], 'NEW']

                 // ------Insert the item-------------------
                        
                        mylist=[[1,2,3],["Hemali","Devanshi","D"]]
                        mylist.insert(0,100)
                        print(mylist)
                        
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                [100, [1, 2, 3], ['Hemali', 'Devanshi', 'D']]

                // ------Revome the item-------------------

                        mylist=[[1,2,3],["Hemali","Devanshi","D"]]
                        mylist.insert(0,100)
                        list1=mylist
                        mylist.remove(100)
                        print(list1)

                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                [[1, 2, 3], ['Hemali', 'Devanshi', 'D']]
