// ------TUPPLE-------------------

                        tuple1=(1,2,5.0,"Hello")
                        print(tuple1)
                        
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                (1, 2, 5.0, 'Hello')

                // ------retrive the item-------------------

                        tuple1=(1,2,5.0,"Hello")
                        print(tuple1[-1])
                        
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                Hello

                        tuple1=(1,2,5.0,"Hello")
                        print(tuple1[2])
                        
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                5.0

        
                // ------Replace the item-------------------
         
                        tuple1=(1,2,5.0,"Hello")
                        tuple.append(100)
                        print(tuple1[-1])
                        
                                type(mylist)
                                Out[20]: list
                        
                // ------reverse the item-------------------

                        mylist=[[1,2,3],["Hemali","Devanshi","D"]]
                        mylist.reverse()
                        print(mylist)
                        
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                [['Hemali', 'Devanshi', 'D'], [1, 2, 3]]

                // ------sorting the item-------------------

                        mylist=[10,20,30,40,50,60,1000,250]
                        l1=sorted(mylist)
                        print(l1)
                        
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                [10, 20, 30, 40, 50, 60, 250, 1000]

                // ------for loop the item-------------------

                        mylist=[10,20,30,40,50,60,1000,250]
                        for i in mylist:
                            print(i)
                                
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                10
                                20
                                30
                                40
                                50
                                60
                                1000
                                250

        
                        // ------multi the item-------------------

                        mylist=[10,20,30,40,50,60,1000,250]
                        for i in mylist:
                            print(i*2)
                        
                                runfile('B:/ICT3-1/SPYDER/ARRAY.py', wdir='B:/ICT3-1/SPYDER')
                                20
                                40
                                60
                                80
                                100
                                120
                                2000
                                500
                // -------------------------
